﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace makeup1.Models
{
    public class Follower
    {
        public int ID { get; set; }
        public string FollowerName { get; set; }
        public string FollowerUserId { get; set; }
    }
}